<?php

namespace Drupal\clockwidget\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class MySubscription.
 */
class MySubscription extends ControllerBase {

  /**
   *
   */
  public function render() {

    // Some functions.
  }

}
